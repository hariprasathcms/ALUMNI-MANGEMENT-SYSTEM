import { Alumni } from './types';

export const DEGREES = [
  'Bachelor of Science (B.S.)',
  'Bachelor of Arts (B.A.)',
  'Master of Science (M.S.)',
  'Master of Arts (M.A.)',
  'Master of Business Administration (MBA)',
  'Doctor of Philosophy (Ph.D.)',
  'Associate Degree',
  'Other'
];

export const INITIAL_ALUMNI_DATA: Alumni[] = [
  {
    id: '1',
    firstName: 'Alice',
    lastName: 'Johnson',
    email: 'alice.j@example.com',
    phone: '555-0101',
    graduationYear: 2019,
    degree: 'Bachelor of Science (B.S.)',
    major: 'Computer Science',
    currentEmployer: 'TechNova Inc.',
    jobTitle: 'Software Engineer',
    linkedInUrl: 'https://linkedin.com/in/alicej',
    notes: 'Active donor.'
  },
  {
    id: '2',
    firstName: 'Bob',
    lastName: 'Smith',
    email: 'bob.smith@example.com',
    phone: '555-0102',
    graduationYear: 2018,
    degree: 'Master of Business Administration (MBA)',
    major: 'Marketing',
    currentEmployer: 'Global Corp',
    jobTitle: 'Product Manager',
  }
];
