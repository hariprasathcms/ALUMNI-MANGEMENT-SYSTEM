import React, { useState, useEffect } from 'react';
import { Alumni, ViewState, UserRole } from './types';
import { alumniService } from './services/storageService';
import { generateCareerInsights } from './services/geminiService';
import AlumniList from './components/AlumniList';
import AlumniForm from './components/AlumniForm';
import StatsDashboard from './components/StatsDashboard';
import LoginPage from './components/LoginPage';
import InformationPage from './components/InformationPage';
import { GraduationCap, Users, Plus, BarChart3, Sparkles, LogOut, Loader2, Info } from 'lucide-react';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState<UserRole>('ADMIN');
  const [view, setView] = useState<ViewState>('LIST');
  
  const [alumniData, setAlumniData] = useState<Alumni[]>([]);
  const [isLoadingData, setIsLoadingData] = useState(false);
  
  const [editingAlumni, setEditingAlumni] = useState<Alumni | null>(null);
  
  // AI Insights State
  const [insights, setInsights] = useState<string | null>(null);
  const [isLoadingInsights, setIsLoadingInsights] = useState(false);

  // Initial Auth Check
  useEffect(() => {
    const auth = localStorage.getItem('alumnet_auth');
    const role = localStorage.getItem('alumnet_role') as UserRole | null;
    
    if (auth === 'true') {
      setIsAuthenticated(true);
      if (role) setUserRole(role);
    }
  }, []);

  // Fetch Data when Authenticated
  useEffect(() => {
    if (isAuthenticated) {
      loadAlumniData();
    }
  }, [isAuthenticated]);

  const loadAlumniData = async () => {
    setIsLoadingData(true);
    try {
      const data = await alumniService.getAll();
      setAlumniData(data);
    } catch (error) {
      console.error("Failed to fetch alumni data", error);
      // Fallback or error notification could go here
    } finally {
      setIsLoadingData(false);
    }
  };

  const handleLogin = (role: UserRole) => {
    localStorage.setItem('alumnet_auth', 'true');
    localStorage.setItem('alumnet_role', role);
    setUserRole(role);
    setIsAuthenticated(true);
    // Default view based on role
    setView(role === 'ALUMNI' ? 'INFO' : 'LIST');
  };

  const handleLogout = () => {
    localStorage.removeItem('alumnet_auth');
    localStorage.removeItem('alumnet_role');
    setIsAuthenticated(false);
    setView('LIST');
    setInsights(null);
    setAlumniData([]);
    setUserRole('ADMIN'); // Reset to default
  };

  const handleSave = async (alumni: Alumni) => {
    if (userRole !== 'ADMIN') return; // Security check

    setIsLoadingData(true);
    try {
      if (editingAlumni) {
        await alumniService.update(alumni);
      } else {
        await alumniService.create(alumni);
      }
      // Refresh data to ensure sync with backend
      await loadAlumniData();
      setView('LIST');
      setEditingAlumni(null);
    } catch (error) {
      console.error("Error saving alumni", error);
      alert("Failed to save record. Please try again.");
      setIsLoadingData(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (userRole !== 'ADMIN') return; // Security check

    if (window.confirm('Are you sure you want to delete this alumni record?')) {
      setIsLoadingData(true);
      try {
        await alumniService.delete(id);
        await loadAlumniData();
      } catch (error) {
        console.error("Error deleting alumni", error);
        alert("Failed to delete record.");
        setIsLoadingData(false);
      }
    }
  };

  const startEdit = (alumni: Alumni) => {
    setEditingAlumni(alumni);
    setView('EDIT');
  };

  const handleGetInsights = async () => {
    setIsLoadingInsights(true);
    const result = await generateCareerInsights(alumniData);
    setInsights(result);
    setIsLoadingInsights(false);
  };

  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col md:flex-row animate-in fade-in duration-500">
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-slate-900 text-white flex-shrink-0 flex flex-col shadow-xl z-10">
        <div className="p-6 border-b border-slate-700 flex items-center gap-3">
          <div className="bg-blue-600 p-2 rounded-lg shadow-lg shadow-blue-900/50">
            <GraduationCap size={24} className="text-white" />
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight tracking-tight">AlumNet</h1>
            <p className="text-xs text-slate-400 font-medium">
              {userRole === 'ADMIN' ? 'Admin Portal' : 'Alumni Portal'}
            </p>
          </div>
        </div>
        
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {userRole === 'ALUMNI' && (
            <button 
              onClick={() => setView('INFO')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                view === 'INFO' ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/50' : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Info size={20} />
              <span>News & Events</span>
            </button>
          )}

          <button 
            onClick={() => setView('LIST')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
              view === 'LIST' ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/50' : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Users size={20} />
            <span>Directory</span>
          </button>
          
          {userRole === 'ADMIN' && (
            <>
              <button 
                onClick={() => { setEditingAlumni(null); setView('ADD'); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                  view === 'ADD' ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/50' : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Plus size={20} />
                <span>Add Alumni</span>
              </button>

              <button 
                onClick={() => setView('STATS')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                  view === 'STATS' ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/50' : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <BarChart3 size={20} />
                <span>Dashboard</span>
              </button>
            </>
          )}
        </nav>

        <div className="p-4 space-y-4 border-t border-slate-800">
          {userRole === 'ADMIN' && (
            <div className="bg-slate-800 rounded-xl p-4 border border-slate-700/50">
              <h4 className="text-xs font-bold text-slate-400 uppercase mb-2 flex items-center gap-1">
                 <Sparkles size={12} className="text-yellow-400" /> AI Insights
              </h4>
              <p className="text-xs text-slate-300 mb-3 leading-relaxed">
                Analyze your alumni network trends.
              </p>
              <button 
                onClick={handleGetInsights}
                disabled={isLoadingInsights}
                className="w-full py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-xs font-semibold rounded text-white transition flex items-center justify-center gap-2 shadow-lg shadow-indigo-900/20"
              >
                {isLoadingInsights ? 'Analyzing...' : 'Generate Report'}
              </button>
              
              {insights && (
                 <div className="mt-3 p-3 bg-slate-700/80 rounded-lg text-xs text-slate-200 animate-in fade-in border border-slate-600">
                    <div dangerouslySetInnerHTML={{__html: insights}} className="list-disc pl-4 space-y-1.5" />
                    <button 
                      onClick={() => setInsights(null)} 
                      className="mt-3 text-[10px] text-slate-400 hover:text-white font-medium transition"
                    >
                      Dismiss
                    </button>
                 </div>
              )}
            </div>
          )}

          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 text-slate-400 hover:bg-red-900/20 hover:text-red-400 rounded-lg transition-all duration-200 group"
          >
            <LogOut size={20} className="group-hover:translate-x-[-2px] transition-transform" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-4 md:p-8 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8 flex justify-between items-start">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-slate-800 tracking-tight">
                {view === 'LIST' && 'Alumni Directory'}
                {view === 'ADD' && 'Register New Alumni'}
                {view === 'EDIT' && 'Update Details'}
                {view === 'STATS' && 'Network Analytics'}
                {view === 'INFO' && 'Institute Bulletin'}
              </h2>
              <p className="text-slate-500 mt-2 text-sm md:text-base">
                {view === 'LIST' && `Viewing ${alumniData.length} records`}
                {view === 'ADD' && 'Enter the details of the graduate below'}
                {view === 'EDIT' && 'Modify the existing alumni record'}
                {view === 'STATS' && 'Visualizing the growth and success of your graduates'}
                {view === 'INFO' && 'Latest updates, events, and announcements for our alumni community'}
              </p>
            </div>
            {isLoadingData && (
              <div className="flex items-center gap-2 text-slate-400 text-sm bg-white px-3 py-1.5 rounded-full shadow-sm border border-slate-100">
                <Loader2 size={16} className="animate-spin" />
                Updating...
              </div>
            )}
          </div>

          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            {view === 'LIST' && (
              <AlumniList 
                data={alumniData} 
                onEdit={startEdit} 
                onDelete={handleDelete}
                userRole={userRole}
              />
            )}
            
            {(view === 'ADD' || view === 'EDIT') && (
              <AlumniForm 
                initialData={editingAlumni} 
                onSave={handleSave} 
                onCancel={() => setView('LIST')} 
              />
            )}

            {view === 'STATS' && (
              <StatsDashboard data={alumniData} />
            )}

            {view === 'INFO' && (
              <InformationPage />
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;