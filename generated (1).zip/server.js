import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import { randomUUID } from 'crypto';

const app = express();
const PORT = 3001;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// In-memory data store (simulating Java Collections/Database)
let alumniDb = [
  {
    id: '1',
    firstName: 'Alice',
    lastName: 'Johnson',
    email: 'alice.j@example.com',
    phone: '555-0101',
    graduationYear: 2019,
    degree: 'Bachelor of Science (B.S.)',
    major: 'Computer Science',
    currentEmployer: 'TechNova Inc.',
    jobTitle: 'Software Engineer',
    linkedInUrl: 'https://linkedin.com/in/alicej',
    notes: 'Active donor.'
  },
  {
    id: '2',
    firstName: 'Bob',
    lastName: 'Smith',
    email: 'bob.smith@example.com',
    phone: '555-0102',
    graduationYear: 2018,
    degree: 'Master of Business Administration (MBA)',
    major: 'Marketing',
    currentEmployer: 'Global Corp',
    jobTitle: 'Product Manager',
    linkedInUrl: '',
    notes: ''
  }
];

// Routes

// GET: Fetch all alumni
app.get('/api/alumni', (req, res) => {
  res.json(alumniDb);
});

// GET: Fetch single alumni by ID
app.get('/api/alumni/:id', (req, res) => {
  const alumni = alumniDb.find(a => a.id === req.params.id);
  if (alumni) {
    res.json(alumni);
  } else {
    res.status(404).json({ message: 'Alumni not found' });
  }
});

// POST: Create new alumni
app.post('/api/alumni', (req, res) => {
  const newAlumni = {
    ...req.body,
    id: req.body.id || randomUUID()
  };
  alumniDb.push(newAlumni);
  res.status(201).json(newAlumni);
});

// PUT: Update existing alumni
app.put('/api/alumni/:id', (req, res) => {
  const index = alumniDb.findIndex(a => a.id === req.params.id);
  if (index !== -1) {
    alumniDb[index] = { ...alumniDb[index], ...req.body };
    res.json(alumniDb[index]);
  } else {
    res.status(404).json({ message: 'Alumni not found' });
  }
});

// DELETE: Remove alumni
app.delete('/api/alumni/:id', (req, res) => {
  const initialLength = alumniDb.length;
  alumniDb = alumniDb.filter(a => a.id !== req.params.id);
  
  if (alumniDb.length < initialLength) {
    res.status(200).json({ message: 'Deleted successfully' });
  } else {
    res.status(404).json({ message: 'Alumni not found' });
  }
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`API available at http://localhost:${PORT}/api/alumni`);
});
