import { Alumni } from '../types';
import { INITIAL_ALUMNI_DATA } from '../constants';

const STORAGE_KEY = 'alumnet_data_v1';
const API_URL = 'http://localhost:3001/api/alumni';

// TOGGLE THIS TO TRUE TO USE THE NODE.JS BACKEND
const USE_BACKEND = false; 

// --- MOCK BACKEND (LocalStorage) ---
const mockDelay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const mockService = {
  getAll: async (): Promise<Alumni[]> => {
    await mockDelay(400);
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      return data ? JSON.parse(data) : INITIAL_ALUMNI_DATA;
    } catch (error) {
      console.error('Failed to load from local storage', error);
      return INITIAL_ALUMNI_DATA;
    }
  },

  create: async (alumni: Alumni): Promise<Alumni> => {
    await mockDelay(400);
    const currentData = await mockService.getAll();
    const newData = [...currentData, alumni];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
    return alumni;
  },

  update: async (alumni: Alumni): Promise<Alumni> => {
    await mockDelay(400);
    const currentData = await mockService.getAll();
    const newData = currentData.map(item => item.id === alumni.id ? alumni : item);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
    return alumni;
  },

  delete: async (id: string): Promise<void> => {
    await mockDelay(400);
    const currentData = await mockService.getAll();
    const newData = currentData.filter(item => item.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
  }
};

// --- REAL BACKEND (Fetch API) ---
const apiService = {
  getAll: async (): Promise<Alumni[]> => {
    const response = await fetch(API_URL);
    if (!response.ok) throw new Error('Failed to fetch data');
    return response.json();
  },

  create: async (alumni: Alumni): Promise<Alumni> => {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(alumni)
    });
    if (!response.ok) throw new Error('Failed to create record');
    return response.json();
  },

  update: async (alumni: Alumni): Promise<Alumni> => {
    const response = await fetch(`${API_URL}/${alumni.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(alumni)
    });
    if (!response.ok) throw new Error('Failed to update record');
    return response.json();
  },

  delete: async (id: string): Promise<void> => {
    const response = await fetch(`${API_URL}/${id}`, {
      method: 'DELETE'
    });
    if (!response.ok) throw new Error('Failed to delete record');
  }
};

// Export the selected service
export const alumniService = USE_BACKEND ? apiService : mockService;

// Keep synchronous helpers for initial state if needed, but prefer async service
export const getLocalDataSync = (): Alumni[] => {
   const data = localStorage.getItem(STORAGE_KEY);
   return data ? JSON.parse(data) : INITIAL_ALUMNI_DATA;
};
