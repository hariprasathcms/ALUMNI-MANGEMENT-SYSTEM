import { GoogleGenAI } from "@google/genai";
import { Alumni } from '../types';

const getAiClient = () => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY is missing from environment variables");
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const generateOutreachEmail = async (alumni: Alumni, purpose: string): Promise<string> => {
  try {
    const ai = getAiClient();
    const model = 'gemini-2.5-flash';

    const prompt = `
      Write a professional and warm outreach email to an alumni from our institute.
      
      Alumni Details:
      Name: ${alumni.firstName} ${alumni.lastName}
      Graduation Year: ${alumni.graduationYear}
      Degree: ${alumni.degree} in ${alumni.major}
      Current Role: ${alumni.jobTitle} at ${alumni.currentEmployer}
      
      Purpose of Email: ${purpose}
      
      The tone should be encouraging, polite, and foster a sense of community. 
      Keep it concise (under 200 words).
      Return ONLY the body of the email.
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });

    return response.text || "Failed to generate email.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Error generating email. Please check your API key and try again.";
  }
};

export const generateCareerInsights = async (alumniList: Alumni[]): Promise<string> => {
  try {
    const ai = getAiClient();
    const model = 'gemini-2.5-flash';
    
    // Anonymize data slightly for aggregate analysis
    const dataSummary = alumniList.map(a => ({
      year: a.graduationYear,
      major: a.major,
      role: a.jobTitle,
      company: a.currentEmployer
    }));

    const prompt = `
      Analyze the following alumni career data JSON and provide 3 key insights about career trends for our graduates.
      For example, are certain majors leading to specific tech roles? Are graduates from recent years moving into different sectors?
      
      Data: ${JSON.stringify(dataSummary).substring(0, 10000)}
      
      Format the output as a simple HTML unordered list (<ul><li>...</li></ul>) with no markdown formatting around it.
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });

    return response.text || "No insights available.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Unable to generate insights at this time.";
  }
};
