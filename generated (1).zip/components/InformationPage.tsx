import React from 'react';
import { Calendar, Newspaper, Megaphone, ExternalLink, MapPin, Clock } from 'lucide-react';

const InformationPage: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10">
          <h1 className="text-3xl font-bold mb-2">Alumni News & Events</h1>
          <p className="text-blue-100 text-lg max-w-2xl">
            Stay connected with your alma mater, keep up with campus updates, and join us for upcoming reunions and networking opportunities.
          </p>
        </div>
        <div className="absolute right-0 top-0 h-full w-1/3 bg-white/5 skew-x-12 transform translate-x-8"></div>
        <div className="absolute right-20 top-[-50%] h-64 w-64 bg-blue-400/20 rounded-full blur-3xl"></div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Feed */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
              <Newspaper className="text-blue-600" /> Latest Updates
            </h2>
            <span className="text-xs font-medium text-slate-500 uppercase">Last updated: Today</span>
          </div>

          {/* News Item 1 */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 hover:shadow-md transition group cursor-pointer">
            <div className="flex justify-between items-start">
              <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wide bg-blue-50 px-2 py-1 rounded-full border border-blue-100">Campus News</span>
              <span className="text-xs text-slate-400">Oct 15, 2023</span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 mt-3 mb-2 group-hover:text-blue-600 transition-colors">
              New Science Wing Opening Ceremony
            </h3>
            <p className="text-slate-600 leading-relaxed mb-4 text-sm">
              We are thrilled to announce the grand opening of the new Advanced Sciences building. This state-of-the-art facility features 12 new labs, a robotics center, and collaborative study spaces. Alumni are invited to the ribbon-cutting ceremony.
            </p>
            <div className="flex items-center gap-4 text-xs font-medium text-slate-400">
              <span className="flex items-center gap-1"><Clock size={12}/> 5 min read</span>
              <span>•</span>
              <span className="text-blue-500 group-hover:underline">Read more</span>
            </div>
          </div>

           {/* News Item 2 */}
           <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 hover:shadow-md transition group cursor-pointer">
             <div className="flex justify-between items-start">
              <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wide bg-emerald-50 px-2 py-1 rounded-full border border-emerald-100">Achievement</span>
              <span className="text-xs text-slate-400">Sep 28, 2023</span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 mt-3 mb-2 group-hover:text-blue-600 transition-colors">
              Alumni of the Year Awards
            </h3>
            <p className="text-slate-600 leading-relaxed mb-4 text-sm">
              Nominations are now open for the prestigious Alumni of the Year award. We are looking for graduates who have made significant contributions to their field or community. Submit your nominations before the end of the semester.
            </p>
            <div className="flex items-center gap-4 text-xs font-medium text-slate-400">
              <span className="flex items-center gap-1"><Clock size={12}/> 2 min read</span>
              <span>•</span>
              <span className="text-blue-500 group-hover:underline">Read more</span>
            </div>
          </div>

           {/* News Item 3 */}
           <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 hover:shadow-md transition group cursor-pointer">
             <div className="flex justify-between items-start">
              <span className="text-[10px] font-bold text-purple-600 uppercase tracking-wide bg-purple-50 px-2 py-1 rounded-full border border-purple-100">Career</span>
              <span className="text-xs text-slate-400">Sep 10, 2023</span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 mt-3 mb-2 group-hover:text-blue-600 transition-colors">
              Launch of the Global Mentorship Program
            </h3>
            <p className="text-slate-600 leading-relaxed mb-4 text-sm">
              Connect with current students and help guide the next generation of professionals. Our new digital mentorship platform matches you with students based on industry and major.
            </p>
            <div className="flex items-center gap-4 text-xs font-medium text-slate-400">
              <span className="flex items-center gap-1"><Clock size={12}/> 3 min read</span>
              <span>•</span>
              <span className="text-blue-500 group-hover:underline">Read more</span>
            </div>
          </div>
        </div>

        {/* Sidebar / Events */}
        <div className="space-y-6">
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2 pb-2 border-b border-slate-200">
            <Calendar className="text-purple-600" /> Upcoming Events
          </h2>

          <div className="bg-white rounded-xl shadow-sm border border-slate-200 divide-y divide-slate-100 overflow-hidden">
            <div className="p-4 hover:bg-purple-50/30 transition cursor-pointer group">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-14 h-14 bg-purple-100 text-purple-600 rounded-xl flex flex-col items-center justify-center leading-none shadow-inner">
                  <span className="text-[10px] font-bold uppercase tracking-widest mb-0.5">Nov</span>
                  <span className="text-xl font-bold">12</span>
                </div>
                <div>
                  <h4 className="font-bold text-slate-800 group-hover:text-purple-700 transition-colors">Annual Homecoming</h4>
                  <div className="flex items-center gap-1 text-xs text-slate-500 mt-1">
                    <MapPin size={12} /> Main Campus Quad
                  </div>
                  <span className="inline-block mt-2 text-[10px] font-semibold text-purple-600 bg-purple-50 px-2 py-0.5 rounded border border-purple-100">
                    Registration Open
                  </span>
                </div>
              </div>
            </div>

            <div className="p-4 hover:bg-purple-50/30 transition cursor-pointer group">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-14 h-14 bg-indigo-100 text-indigo-600 rounded-xl flex flex-col items-center justify-center leading-none shadow-inner">
                  <span className="text-[10px] font-bold uppercase tracking-widest mb-0.5">Dec</span>
                  <span className="text-xl font-bold">05</span>
                </div>
                <div>
                  <h4 className="font-bold text-slate-800 group-hover:text-indigo-700 transition-colors">Tech Networking Night</h4>
                  <div className="flex items-center gap-1 text-xs text-slate-500 mt-1">
                    <MapPin size={12} /> Innovation Hub
                  </div>
                  <span className="inline-block mt-2 text-[10px] font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                    Limited Spots
                  </span>
                </div>
              </div>
            </div>
            
             <div className="p-4 hover:bg-purple-50/30 transition cursor-pointer group">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-14 h-14 bg-slate-100 text-slate-500 rounded-xl flex flex-col items-center justify-center leading-none shadow-inner">
                  <span className="text-[10px] font-bold uppercase tracking-widest mb-0.5">Jan</span>
                  <span className="text-xl font-bold">20</span>
                </div>
                <div>
                  <h4 className="font-bold text-slate-800 group-hover:text-slate-600 transition-colors">Career Fair 2024</h4>
                  <div className="flex items-center gap-1 text-xs text-slate-500 mt-1">
                    <MapPin size={12} /> Virtual Event
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Links */}
           <div className="bg-slate-800 rounded-xl p-6 text-white shadow-lg">
              <h3 className="font-bold flex items-center gap-2 mb-4 text-lg">
                <Megaphone size={20} className="text-yellow-400" /> Quick Actions
              </h3>
              <ul className="space-y-3 text-sm text-slate-300">
                <li>
                  <a href="#" className="hover:text-white hover:bg-slate-700 p-2 -ml-2 rounded-lg transition flex items-center gap-3">
                    <ExternalLink size={16}/> Update Contact Info
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white hover:bg-slate-700 p-2 -ml-2 rounded-lg transition flex items-center gap-3">
                    <ExternalLink size={16}/> Request Transcript
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white hover:bg-slate-700 p-2 -ml-2 rounded-lg transition flex items-center gap-3">
                    <ExternalLink size={16}/> Alumni Benefits
                  </a>
                </li>
              </ul>
              <div className="mt-6 pt-4 border-t border-slate-700">
                <p className="text-xs text-slate-500">Need assistance?</p>
                <a href="mailto:alumni@institute.edu" className="text-sm font-medium text-blue-400 hover:text-blue-300 transition">
                  Contact Alumni Relations
                </a>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default InformationPage;