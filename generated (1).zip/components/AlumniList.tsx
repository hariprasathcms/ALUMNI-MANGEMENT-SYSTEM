import React, { useState } from 'react';
import { Alumni, SortConfig, UserRole } from '../types';
import { Search, Edit2, Trash2, Mail, Building, ChevronUp, ChevronDown } from 'lucide-react';
import OutreachModal from './OutreachModal';

interface AlumniListProps {
  data: Alumni[];
  onEdit: (alumni: Alumni) => void;
  onDelete: (id: string) => void;
  userRole: UserRole;
}

const AlumniList: React.FC<AlumniListProps> = ({ data, onEdit, onDelete, userRole }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: 'firstName', direction: 'asc' });
  const [selectedForOutreach, setSelectedForOutreach] = useState<Alumni | null>(null);

  const handleSort = (key: keyof Alumni) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const filteredData = data.filter(item => {
    if (!searchTerm.trim()) return true;

    // Split search term into individual words for multi-field matching
    const searchTerms = searchTerm.toLowerCase().trim().split(/\s+/);

    // Create a single string containing all searchable data for this alumni
    const searchableText = [
      item.firstName,
      item.lastName,
      item.email,
      item.currentEmployer,
      item.jobTitle,
      item.major,
      item.degree,
      item.graduationYear.toString(),
      item.phone,
      item.notes,
      item.linkedInUrl
    ].filter(Boolean).join(' ').toLowerCase();

    // Check if every search term is present in the searchable text
    return searchTerms.every(term => searchableText.includes(term));
  }).sort((a, b) => {
    // @ts-ignore
    if (a[sortConfig.key] < b[sortConfig.key]) return sortConfig.direction === 'asc' ? -1 : 1;
    // @ts-ignore
    if (a[sortConfig.key] > b[sortConfig.key]) return sortConfig.direction === 'asc' ? 1 : -1;
    return 0;
  });

  const SortIcon = ({ colKey }: { colKey: keyof Alumni }) => {
    if (sortConfig.key !== colKey) return <div className="w-3 h-3 opacity-0 group-hover:opacity-30" />;
    return sortConfig.direction === 'asc' ? <ChevronUp size={14} className="text-blue-500" /> : <ChevronDown size={14} className="text-blue-500" />;
  };

  const TableHeader = ({ label, colKey, className = "" }: { label: string, colKey: keyof Alumni, className?: string }) => (
    <th 
      className={`px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase tracking-wider cursor-pointer group hover:bg-slate-50/80 transition select-none ${className}`}
      onClick={() => handleSort(colKey)}
    >
      <div className="flex items-center gap-1.5">
        {label}
        <SortIcon colKey={colKey} />
      </div>
    </th>
  );

  return (
    <div className="space-y-6">
      {/* Enhanced Search Bar */}
      <div className="relative max-w-xl">
        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
          <Search size={20} className="text-slate-400" />
        </div>
        <input
          type="text"
          placeholder="Search by name, company, major, or year..."
          className="block w-full pl-11 pr-4 py-3.5 border border-slate-200 rounded-2xl leading-5 bg-white placeholder-slate-400 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition shadow-sm text-slate-700"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        {searchTerm && (
          <div className="absolute inset-y-0 right-4 flex items-center">
             <span className="text-xs text-slate-400 font-medium px-2 py-1 bg-slate-100 rounded-md">{filteredData.length} results</span>
          </div>
        )}
      </div>

      {/* Table Card */}
      <div className="bg-white shadow-lg shadow-slate-200/40 rounded-2xl border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-100">
            <thead className="bg-slate-50/50">
              <tr>
                <TableHeader label="Alumni Profile" colKey="lastName" />
                <TableHeader label="Graduation" colKey="graduationYear" />
                <TableHeader label="Education" colKey="degree" />
                <TableHeader label="Career" colKey="jobTitle" />
                {userRole === 'ADMIN' && (
                  <th className="px-6 py-4 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">Actions</th>
                )}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-100">
              {filteredData.length > 0 ? (
                filteredData.map((person) => (
                  <tr key={person.id} className="hover:bg-blue-50/30 transition duration-150 group">
                    <td className="px-6 py-5 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-12 w-12 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 p-[2px] shadow-md">
                           <div className="h-full w-full rounded-full bg-white flex items-center justify-center">
                             <span className="text-blue-700 font-bold text-lg">
                               {person.firstName[0]}{person.lastName[0]}
                             </span>
                           </div>
                        </div>
                        <div className="ml-4">
                          <div className="text-base font-semibold text-slate-900 group-hover:text-blue-700 transition-colors">
                            {person.firstName} {person.lastName}
                          </div>
                          <div className="text-sm text-slate-500 flex items-center gap-1.5 mt-0.5">
                            <Mail size={13} className="text-slate-400" /> {person.email}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-5 whitespace-nowrap">
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                        Class of {person.graduationYear}
                      </span>
                    </td>
                    <td className="px-6 py-5 whitespace-nowrap">
                       <div className="text-sm font-medium text-slate-800">{person.major}</div>
                       <div className="text-xs text-slate-500 mt-0.5">{person.degree}</div>
                    </td>
                    <td className="px-6 py-5 whitespace-nowrap">
                      {person.currentEmployer ? (
                        <div className="flex flex-col">
                          <span className="text-sm font-medium text-slate-900">{person.jobTitle}</span>
                          <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-0.5">
                            <Building size={12} className="text-slate-400" /> {person.currentEmployer}
                          </div>
                        </div>
                      ) : (
                         <span className="text-sm text-slate-400 italic">Not listed</span>
                      )}
                    </td>
                    
                    {userRole === 'ADMIN' && (
                      <td className="px-6 py-5 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex items-center justify-end gap-1 opacity-60 group-hover:opacity-100 transition-opacity">
                          <button 
                            onClick={() => setSelectedForOutreach(person)}
                            className="p-2 text-slate-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition tooltip-trigger relative"
                            title="AI Outreach"
                          >
                            <Mail size={18} />
                          </button>
                          <div className="w-px h-4 bg-slate-200 mx-1"></div>
                          <button 
                            onClick={() => onEdit(person)}
                            className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition"
                            title="Edit"
                          >
                            <Edit2 size={18} />
                          </button>
                          <button 
                            onClick={() => onDelete(person.id)}
                            className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                            title="Delete"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={userRole === 'ADMIN' ? 5 : 4} className="px-6 py-16 text-center">
                    <div className="flex flex-col items-center justify-center">
                      <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mb-4 shadow-inner">
                        <Search size={32} className="text-slate-300" />
                      </div>
                      <h3 className="text-lg font-medium text-slate-900">No matching records found</h3>
                      <p className="text-slate-500 text-sm mt-1 max-w-xs mx-auto">
                        We couldn't find any alumni matching "{searchTerm}". Try checking for typos or using broader keywords.
                      </p>
                      <button 
                        onClick={() => setSearchTerm('')}
                        className="mt-4 text-sm font-medium text-blue-600 hover:text-blue-700 hover:underline"
                      >
                        Clear Search
                      </button>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        {/* Table Footer / Summary */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-100 flex justify-between items-center">
          <p className="text-xs text-slate-500 font-medium">
             Showing {filteredData.length} of {data.length} records
          </p>
          <div className="flex gap-2">
             <span className="w-2 h-2 rounded-full bg-green-400"></span>
             <span className="text-xs text-slate-400">System Online</span>
          </div>
        </div>
      </div>

      {selectedForOutreach && (
        <OutreachModal 
          alumni={selectedForOutreach} 
          onClose={() => setSelectedForOutreach(null)} 
        />
      )}
    </div>
  );
};

export default AlumniList;