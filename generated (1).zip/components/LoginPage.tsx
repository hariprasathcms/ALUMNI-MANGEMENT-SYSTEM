import React, { useState } from 'react';
import { GraduationCap, Lock, User, ArrowRight, AlertCircle, CheckCircle2, ShieldCheck, School } from 'lucide-react';
import { UserRole } from '../types';

interface LoginPageProps {
  onLogin: (role: UserRole) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [activeRole, setActiveRole] = useState<UserRole>('ADMIN');
  
  // Admin Credentials
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  
  // Alumni Credentials
  const [alumniUser, setAlumniUser] = useState('');
  const [alumniPass, setAlumniPass] = useState('');

  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate network delay
    setTimeout(() => {
      let isValid = false;

      if (activeRole === 'ADMIN') {
        // Mock Admin Validation
        if (username.trim() && password.trim()) {
          isValid = true;
        } else {
          setError('Invalid administrative credentials.');
        }
      } else {
        // Mock Alumni Validation
        if (alumniUser.trim() && alumniPass.trim()) {
          isValid = true;
        } else {
          setError('Invalid alumni username or password.');
        }
      }

      if (isValid) {
        setIsSuccess(true);
        setTimeout(() => {
           onLogin(activeRole);
        }, 800);
      } else {
        setIsLoading(false);
      }
    }, 1000);
  };

  return (
    <div className={`min-h-screen flex items-center justify-center p-4 font-sans relative overflow-hidden transition-colors duration-700 ${activeRole === 'ADMIN' ? 'bg-slate-900' : 'bg-blue-50'}`}>
      
      {/* Background Decoration */}
      <div className="absolute inset-0 z-0">
        {activeRole === 'ADMIN' ? (
          <>
            <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900"></div>
            <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-blue-600/20 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-100 contrast-150 mix-blend-overlay"></div>
          </>
        ) : (
          <>
             <div className="absolute inset-0 bg-gradient-to-tr from-blue-100 via-white to-blue-50"></div>
             <div className="absolute top-20 right-20 w-64 h-64 bg-blue-200/30 rounded-full blur-3xl"></div>
             <div className="absolute bottom-20 left-20 w-80 h-80 bg-indigo-200/30 rounded-full blur-3xl"></div>
          </>
        )}
      </div>

      <div className={`max-w-md w-full bg-white rounded-2xl shadow-2xl overflow-hidden transition-all duration-500 transform z-10 ${isSuccess ? 'scale-[0.98] opacity-0' : 'scale-100 opacity-100'}`}>
        
        {/* Role Toggles */}
        <div className="flex border-b border-slate-100">
          <button
            type="button"
            onClick={() => { setActiveRole('ADMIN'); setError(''); }}
            className={`flex-1 py-4 text-sm font-bold text-center transition-colors flex items-center justify-center gap-2 ${
              activeRole === 'ADMIN' 
                ? 'bg-slate-50 text-slate-900 border-b-2 border-blue-600' 
                : 'bg-white text-slate-400 hover:text-slate-600 hover:bg-slate-50'
            }`}
          >
            <ShieldCheck size={16} /> Admin Portal
          </button>
          <button
            type="button"
            onClick={() => { setActiveRole('ALUMNI'); setError(''); }}
            className={`flex-1 py-4 text-sm font-bold text-center transition-colors flex items-center justify-center gap-2 ${
              activeRole === 'ALUMNI' 
                ? 'bg-blue-50/50 text-blue-700 border-b-2 border-blue-600' 
                : 'bg-white text-slate-400 hover:text-slate-600 hover:bg-slate-50'
            }`}
          >
            <School size={16} /> Alumni Login
          </button>
        </div>

        <div className="p-8">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <div className={`p-3 rounded-xl shadow-lg transition-colors duration-300 ${activeRole === 'ADMIN' ? 'bg-slate-800 shadow-slate-800/30' : 'bg-blue-600 shadow-blue-600/30'}`}>
                <GraduationCap size={32} className="text-white" />
              </div>
            </div>
            <h1 className="text-2xl font-bold text-slate-800 tracking-tight">
              {activeRole === 'ADMIN' ? 'Institute Administration' : 'Alumni Community'}
            </h1>
            <p className="text-slate-500 mt-1 text-sm">
              {activeRole === 'ADMIN' ? 'Secure System Access' : 'Connect with your alma mater'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {error && (
              <div className="bg-red-50 text-red-600 text-xs font-medium p-3 rounded-lg flex items-center gap-2 border border-red-100 animate-in slide-in-from-top-1">
                <AlertCircle size={16} className="flex-shrink-0" />
                {error}
              </div>
            )}

            {activeRole === 'ADMIN' ? (
              // ADMIN FORM
              <>
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Username</label>
                  <div className="relative group">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none transition-colors group-focus-within:text-blue-600 text-slate-400">
                      <User size={18} />
                    </div>
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="admin"
                      className="block w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all placeholder-slate-400 text-slate-700 text-sm font-medium"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Password</label>
                  <div className="relative group">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none transition-colors group-focus-within:text-blue-600 text-slate-400">
                      <Lock size={18} />
                    </div>
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="block w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all placeholder-slate-400 text-slate-700 text-sm font-medium"
                    />
                  </div>
                </div>
              </>
            ) : (
              // ALUMNI FORM
              <>
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Username</label>
                  <div className="relative group">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none transition-colors group-focus-within:text-blue-600 text-slate-400">
                      <User size={18} />
                    </div>
                    <input
                      type="text"
                      value={alumniUser}
                      onChange={(e) => setAlumniUser(e.target.value)}
                      placeholder="Student ID or Username"
                      className="block w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all placeholder-slate-400 text-slate-700 text-sm font-medium"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Password</label>
                  <div className="relative group">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none transition-colors group-focus-within:text-blue-600 text-slate-400">
                      <Lock size={18} />
                    </div>
                    <input
                      type="password"
                      value={alumniPass}
                      onChange={(e) => setAlumniPass(e.target.value)}
                      placeholder="••••••••"
                      className="block w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all placeholder-slate-400 text-slate-700 text-sm font-medium"
                    />
                  </div>
                </div>
              </>
            )}

            <button
              type="submit"
              disabled={isLoading || isSuccess}
              className={`w-full flex items-center justify-center gap-2 font-bold py-3 px-4 rounded-lg transition-all duration-300 mt-4 ${
                isSuccess 
                  ? 'bg-green-500 hover:bg-green-600 text-white' 
                  : activeRole === 'ADMIN'
                    ? 'bg-slate-900 hover:bg-slate-800 text-white shadow-lg shadow-slate-900/20'
                    : 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-600/20'
              } disabled:opacity-70 disabled:cursor-not-allowed text-sm`}
            >
              {isLoading ? (
                isSuccess ? (
                  <>
                    <CheckCircle2 size={18} className="animate-bounce" /> {activeRole === 'ADMIN' ? 'Verified' : 'Welcome Back'}
                  </>
                ) : (
                  <Loader2 size={18} className="animate-spin" />
                )
              ) : (
                <>
                  {activeRole === 'ADMIN' ? 'Authenticate' : 'Access Directory'} <ArrowRight size={16} />
                </>
              )}
            </button>
          </form>

          <div className="mt-6 text-center border-t border-slate-50 pt-4">
            <p className="text-[10px] text-slate-400">
              {activeRole === 'ADMIN' 
                ? 'Restricted Area • Authorized Personnel Only' 
                : 'Need help accessing your account? Contact Alumni Relations.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper component for loading spinner
const Loader2 = ({ size = 24, className = "" }: { size?: number, className?: string }) => (
  <svg 
    className={className} 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round"
  >
    <path d="M21 12a9 9 0 1 1-6.219-8.56" />
  </svg>
);

export default LoginPage;