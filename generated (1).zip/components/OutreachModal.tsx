import React, { useState } from 'react';
import { Alumni } from '../types';
import { generateOutreachEmail } from '../services/geminiService';
import { Send, Sparkles, X, Copy, Check } from 'lucide-react';

interface OutreachModalProps {
  alumni: Alumni;
  onClose: () => void;
}

const OutreachModal: React.FC<OutreachModalProps> = ({ alumni, onClose }) => {
  const [purpose, setPurpose] = useState('');
  const [generatedEmail, setGeneratedEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleGenerate = async () => {
    if (!purpose.trim()) return;
    setIsLoading(true);
    const text = await generateOutreachEmail(alumni, purpose);
    setGeneratedEmail(text);
    setIsLoading(false);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedEmail);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg flex flex-col max-h-[90vh]">
        <div className="p-4 border-b border-slate-100 flex justify-between items-center">
          <h3 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
            <Sparkles size={18} className="text-purple-500" />
            Smart Outreach: {alumni.firstName} {alumni.lastName}
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X size={20} />
          </button>
        </div>

        <div className="p-6 overflow-y-auto flex-1">
          <div className="mb-6">
            <label className="block text-sm font-medium text-slate-700 mb-2">
              What is the purpose of this email?
            </label>
            <div className="relative">
              <textarea
                value={purpose}
                onChange={(e) => setPurpose(e.target.value)}
                placeholder="e.g., Inviting them to speak at the annual gala, requesting a donation, or catching up."
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none resize-none h-24 text-sm"
              />
              <button
                onClick={handleGenerate}
                disabled={isLoading || !purpose.trim()}
                className={`absolute bottom-3 right-3 px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition ${
                  isLoading || !purpose.trim() 
                    ? 'bg-slate-100 text-slate-400 cursor-not-allowed' 
                    : 'bg-purple-600 text-white hover:bg-purple-700 shadow-sm'
                }`}
              >
                {isLoading ? 'Thinking...' : <><Sparkles size={12} /> Generate Draft</>}
              </button>
            </div>
          </div>

          {generatedEmail && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Generated Draft</label>
                <button 
                  onClick={handleCopy}
                  className="text-slate-500 hover:text-blue-600 flex items-center gap-1 text-xs font-medium transition"
                >
                  {copied ? <Check size={14} /> : <Copy size={14} />}
                  {copied ? 'Copied!' : 'Copy Text'}
                </button>
              </div>
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 text-sm text-slate-700 whitespace-pre-wrap leading-relaxed">
                {generatedEmail}
              </div>
            </div>
          )}
        </div>
        
        <div className="p-4 border-t border-slate-100 bg-slate-50 rounded-b-xl flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-200 rounded-lg transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default OutreachModal;
