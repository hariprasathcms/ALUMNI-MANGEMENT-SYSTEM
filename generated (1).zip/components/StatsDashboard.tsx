import React, { useMemo } from 'react';
import { Alumni } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface StatsDashboardProps {
  data: Alumni[];
}

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];

const StatsDashboard: React.FC<StatsDashboardProps> = ({ data }) => {
  const graduationData = useMemo(() => {
    const counts: Record<string, number> = {};
    data.forEach(a => {
      const year = a.graduationYear.toString();
      counts[year] = (counts[year] || 0) + 1;
    });
    return Object.keys(counts)
      .sort()
      .map(year => ({ name: year, count: counts[year] }));
  }, [data]);

  const degreeData = useMemo(() => {
    const counts: Record<string, number> = {};
    data.forEach(a => {
      const degree = a.degree.split('(')[0].trim(); // Simplify names
      counts[degree] = (counts[degree] || 0) + 1;
    });
    return Object.keys(counts).map(deg => ({ name: deg, value: counts[deg] }));
  }, [data]);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-800">Institute Overview</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
           <h3 className="text-sm font-medium text-slate-500 uppercase mb-1">Total Alumni</h3>
           <p className="text-4xl font-bold text-slate-900">{data.length}</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
           <h3 className="text-sm font-medium text-slate-500 uppercase mb-1">Latest Grad Year</h3>
           <p className="text-4xl font-bold text-blue-600">
             {data.length > 0 ? Math.max(...data.map(a => a.graduationYear)) : 'N/A'}
           </p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
           <h3 className="text-sm font-medium text-slate-500 uppercase mb-1">Active Companies</h3>
           <p className="text-4xl font-bold text-emerald-600">
             {new Set(data.filter(a => a.currentEmployer).map(a => a.currentEmployer)).size}
           </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Grad Year Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 h-80">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Graduates per Year</h3>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={graduationData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" tick={{fontSize: 12}} />
              <YAxis allowDecimals={false} tick={{fontSize: 12}} />
              <Tooltip 
                contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} 
              />
              <Bar dataKey="count" fill="#3B82F6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Degrees Pie Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 h-80">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Degree Distribution</h3>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={degreeData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {degreeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap justify-center gap-3 text-xs mt-2">
            {degreeData.map((entry, index) => (
               <div key={entry.name} className="flex items-center gap-1">
                 <span className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }}></span>
                 <span className="text-slate-600">{entry.name}</span>
               </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatsDashboard;
