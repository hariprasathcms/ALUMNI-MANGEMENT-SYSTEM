export interface Alumni {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  graduationYear: number;
  degree: string;
  major: string;
  currentEmployer: string;
  jobTitle: string;
  linkedInUrl?: string;
  notes?: string;
}

export type ViewState = 'LIST' | 'ADD' | 'EDIT' | 'STATS' | 'INFO';

export type UserRole = 'ADMIN' | 'ALUMNI';

export interface SortConfig {
  key: keyof Alumni;
  direction: 'asc' | 'desc';
}